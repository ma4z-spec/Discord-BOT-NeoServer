const { Client, GatewayIntentBits, Events } = require('discord.js');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const { token } = require('./config.json');

const client = new Client({ 
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers] 
});

client.once('ready', () => {
  console.log('Ready!');
  
  // Set the bot's activity status
  client.user.setActivity('Playing With Test', { type: 'PLAYING' });

  // Load and display commands
  const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
  console.log(`Loaded commands: ${commandFiles.map(file => file.replace('.js', '')).join(', ')}`);
});

// Command handler
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isCommand()) return;

  const command = interaction.commandName;
  const commandFile = `./commands/${command}.js`;

  if (fs.existsSync(commandFile)) {
    const { execute } = require(commandFile);
    await execute(interaction);
  } else {
    await interaction.reply('Command not found!');
  }
});

// Welcome new members
client.on(Events.GuildMemberAdd, async (member) => {
  const welcomeChannel = member.guild.channels.cache.find(channel => channel.name === 'welcome');
  if (welcomeChannel) {
    welcomeChannel.send(`Welcome to the server, ${member}!`);
  }
});

// Initialize SQLite Database
const db = new sqlite3.Database('./bot_data.sqlite', (err) => {
  if (err) {
    console.error(err.message);
  } else {
    db.run('CREATE TABLE IF NOT EXISTS users (userID TEXT PRIMARY KEY, balance INTEGER DEFAULT 0)', (err) => {
      if (err) {
        console.error(err.message);
      }
    });
  }
});

// Login to Discord
client.login(token);
