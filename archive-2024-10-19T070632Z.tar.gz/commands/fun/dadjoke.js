const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dadjoke')
    .setDescription('Get a dad joke'),

  async execute(interaction) {
    const jokes = [
      "I'm afraid for the calendar. Its days are numbered.",
      "Why don't skeletons fight each other? They don't have the guts.",
      "What did one ocean say to the other ocean? Nothing, they just waved.",
    ];
    
    const joke = jokes[Math.floor(Math.random() * jokes.length)];
    await interaction.reply(joke);
  },
};
