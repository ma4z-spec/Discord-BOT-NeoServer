const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('8ball')
    .setDescription('Ask the magic 8-ball a question')
    .addStringOption(option => 
      option.setName('question')
        .setDescription('The question to ask')
        .setRequired(true)),

  async execute(interaction) {
    const responses = [
      "Yes.",
      "No.",
      "Maybe.",
      "Ask again later.",
      "Definitely.",
      "I don't think so.",
    ];
    
    const question = interaction.options.getString('question');
    const response = responses[Math.floor(Math.random() * responses.length)];
    await interaction.reply(`🎱 ${response}`);
  },
};
