const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Open a support ticket')
    .addStringOption(option => 
      option.setName('category')
        .setDescription('Select a category for the ticket')
        .setRequired(true)),

  async execute(interaction) {
    const category = interaction.options.getString('category');
    const ticketChannel = await interaction.guild.channels.create(`ticket-${interaction.user.username}`, {
      type: 'GUILD_TEXT',
      parent: category,
      permissionOverwrites: [
        {
          id: interaction.guild.roles.everyone,
          deny: ['VIEW_CHANNEL'],
        },
        {
          id: interaction.user.id,
          allow: ['VIEW_CHANNEL'],
        },
      ],
    });
    
    await interaction.reply(`Ticket created: ${ticketChannel}`);
  },
};
