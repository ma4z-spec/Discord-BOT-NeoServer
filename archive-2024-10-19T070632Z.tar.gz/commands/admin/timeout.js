const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout a user')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to timeout')
        .setRequired(true))
    .addIntegerOption(option => 
      option.setName('duration')
        .setDescription('Duration in seconds')
        .setRequired(true)),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const duration = interaction.options.getInteger('duration');
    
    const member = await interaction.guild.members.fetch(user.id);
    await member.timeout(duration * 1000);
    await interaction.reply(`Timed out ${user.tag} for ${duration} seconds.`);
  },
};
