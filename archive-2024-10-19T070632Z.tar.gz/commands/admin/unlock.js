const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unlock')
    .setDescription('Unlock a channel'),

  async execute(interaction) {
    const channel = interaction.channel;
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { SEND_MESSAGES: true });
    await interaction.reply(`Channel ${channel.name} is now unlocked.`);
  },
};
