const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('lock')
    .setDescription('Lock a channel'),

  async execute(interaction) {
    const channel = interaction.channel;
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, { SEND_MESSAGES: false });
    await interaction.reply(`Channel ${channel.name} is now locked.`);
  },
};
