const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('List all commands'),

  async execute(interaction) {
    const helpMessage = `
      Here are the available commands:
      - /ban: Ban a user
      - /kick: Kick a user
      - /lock: Lock a channel
      - /unlock: Unlock a channel
      - /unban: Unban a user
      - /ticket: Open a support ticket
      - /dadjoke: Get a dad joke
      - /8ball: Ask the magic 8-ball a question
      - /balance: Check your balance
      - /gamble: Gamble your coins
      - /bank: Check your bank details
      - /transfer: Transfer coins to another user
    `;

    await interaction.reply(helpMessage);
  },
};
