const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('bank')
    .setDescription('Check your bank details'),

  async execute(interaction) {
    // Implement your bank details logic here
    await interaction.reply('This command is not implemented yet.');
  },
};
