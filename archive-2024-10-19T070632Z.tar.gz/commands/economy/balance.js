const { SlashCommandBuilder } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your balance'),

  async execute(interaction) {
    const db = new sqlite3.Database('./bot_data.sqlite');

    db.get('SELECT balance FROM users WHERE userID = ?', [interaction.user.id], (err, row) => {
      if (err || !row) {
        return interaction.reply('You have no balance.');
      }
      
      interaction.reply(`Your balance is: ${row.balance} coins`);
    });
  },
};
