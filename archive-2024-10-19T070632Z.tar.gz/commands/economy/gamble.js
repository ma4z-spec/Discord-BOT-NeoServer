const { SlashCommandBuilder } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('gamble')
    .setDescription('Gamble your coins')
    .addIntegerOption(option => 
      option.setName('amount')
        .setDescription('Amount to gamble')
        .setRequired(true)),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const db = new sqlite3.Database('./bot_data.sqlite');

    db.get('SELECT balance FROM users WHERE userID = ?', [interaction.user.id], (err, row) => {
      if (err || !row || row.balance < amount) {
        return interaction.reply('You do not have enough balance.');
      }

      const win = Math.random() < 0.5; // 50% chance to win

      if (win) {
        const newBalance = row.balance + amount;
        db.run('UPDATE users SET balance = ? WHERE userID = ?', [newBalance, interaction.user.id]);
        interaction.reply(`You won! Your new balance is: ${newBalance} coins`);
      } else {
        const newBalance = row.balance - amount;
        db.run('UPDATE users SET balance = ? WHERE userID = ?', [newBalance, interaction.user.id]);
        interaction.reply(`You lost! Your new balance is: ${newBalance} coins`);
      }
    });
  },
};
