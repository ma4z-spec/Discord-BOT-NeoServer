const { SlashCommandBuilder } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();

module.exports = {
  data: new SlashCommandBuilder()
    .setName('transfer')
    .setDescription('Transfer coins to another user')
    .addUserOption(option => 
      option.setName('user')
        .setDescription('The user to transfer coins to')
        .setRequired(true))
    .addIntegerOption(option => 
      option.setName('amount')
        .setDescription('Amount to transfer')
        .setRequired(true)),

  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const db = new sqlite3.Database('./bot_data.sqlite');

    // Check if the sender has enough balance
    db.get('SELECT balance FROM users WHERE userID = ?', [interaction.user.id], (err, row) => {
      if (err || !row || row.balance < amount) {
        return interaction.reply('You do not have enough balance.');
      }

      // Check if the receiver exists
      db.get('SELECT balance FROM users WHERE userID = ?', [user.id], (err, receiverRow) => {
        if (err || !receiverRow) {
          return interaction.reply('Receiver does not exist.');
        }

        // Update balances
        const newSenderBalance = row.balance - amount;
        const newReceiverBalance = receiverRow.balance + amount;

        db.run('UPDATE users SET balance = ? WHERE userID = ?', [newSenderBalance, interaction.user.id]);
        db.run('UPDATE users SET balance = ? WHERE userID = ?', [newReceiverBalance, user.id]);

        interaction.reply(`Transferred ${amount} coins to ${user.tag}.`);
      });
    });
  },
};
